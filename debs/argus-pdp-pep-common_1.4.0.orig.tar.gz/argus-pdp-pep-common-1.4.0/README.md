Argus PDP and PEP server common library
=======================================

Java library shared between the Argus PDP and the Argus PEP Server.

http://argus-authz.github.com/argus-pdp-pep-common/
